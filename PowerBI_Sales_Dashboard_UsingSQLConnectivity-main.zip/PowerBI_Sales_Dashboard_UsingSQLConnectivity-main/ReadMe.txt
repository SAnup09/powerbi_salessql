                                
                              
                              Sales Analysis Dashboard using SQL Connectivity





                 Created a sales analysis dashboard in Power BI using SQL connectivity to track key sales metrics, including total revenue, sales quantity, sales quantity by market, total revenue by month, top 5 customers, and top 5 products. The dashboard provides interactive visualizations and real-time data, making it easy to identify trends and patterns and make better decisions about sales strategy.

Benefits

Real-time data and interactive visualizations for easy analysis
Identification of trends and patterns to improve sales strategy
Collaboration with others to make better decisions together